import os
import sqlite3
import logging
from datetime import datetime, timezone
from typing import Optional

from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel, Field
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes
import asyncio
import threading
import uvicorn

BOT_TOKEN = os.environ["TELEGRAM_BOT_TOKEN"]
INGEST_KEY = os.environ["INGEST_KEY"]
DB_PATH = os.getenv("DB_PATH", "aviator_intel.sqlite3")
WINDOW = int(os.getenv("ANALYSIS_WINDOW", "100"))
MIN_SAMPLE = int(os.getenv("MIN_SAMPLE", "30"))

logging.basicConfig(
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    level=logging.INFO
)
log = logging.getLogger("aviator-intel")

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as c:
        c.execute("""CREATE TABLE IF NOT EXISTS rounds (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            multiplier REAL NOT NULL,
            source TEXT NOT NULL,
            created_at TEXT NOT NULL
        )""")
        c.execute("""CREATE TABLE IF NOT EXISTS subscribers (
            chat_id INTEGER PRIMARY KEY
        )""")

def add_subscriber(chat_id: int):
    with db() as c:
        c.execute("INSERT OR IGNORE INTO subscribers(chat_id) VALUES (?)", (chat_id,))

def subscribers():
    with db() as c:
        return [r["chat_id"] for r in c.execute("SELECT chat_id FROM subscribers")]

def add_round(multiplier: float, source: str = "feed"):
    now = datetime.now(timezone.utc).isoformat()
    with db() as c:
        c.execute(
            "INSERT INTO rounds(multiplier, source, created_at) VALUES (?, ?, ?)",
            (multiplier, source, now)
        )

def recent_rounds(limit: int = WINDOW):
    with db() as c:
        return list(c.execute(
            "SELECT multiplier, created_at FROM rounds ORDER BY id DESC LIMIT ?",
            (limit,)
        ))

def total_rounds():
    with db() as c:
        return c.execute("SELECT COUNT(*) AS n FROM rounds").fetchone()["n"]

def analysis():
    rows = recent_rounds(WINDOW)
    vals = [float(r["multiplier"]) for r in rows]
    n = len(vals)
    if not n:
        return {"n": 0, "message": "No rounds received yet."}
    thresholds = [1.5, 2.0, 3.0, 5.0, 10.0]
    rates = {t: sum(v >= t for v in vals) / n * 100 for t in thresholds}
    avg = sum(vals) / n
    # These are descriptive historical frequencies, not forecasts.
    return {"n": n, "avg": avg, "rates": rates, "latest": vals[0],
            "total": total_rounds()}

def format_stats():
    a = analysis()
    if not a["n"]:
        return "No round data yet. Connect an authorized results feed to begin."
    lines = [
        f"📊 *Aviator Intel — last {a['n']} rounds*",
        f"Latest recorded: *{a['latest']:.2f}x*",
        f"Historical average: *{a['avg']:.2f}x*",
        "",
        "Share of this sample reaching each multiplier:"
    ]
    for t, pct in a["rates"].items():
        lines.append(f"• {t:g}x or higher: *{pct:.1f}%*")
    lines += [
        "",
        f"Total rounds stored: {a['total']}",
        "_Past results do not predict the next round. These percentages are descriptive only._"
    ]
    return "\n".join(lines)

def format_signal(multiplier: float):
    a = analysis()
    if a["n"] < MIN_SAMPLE:
        return (
            f"🛰️ *Round recorded: {multiplier:.2f}x*\n"
            f"Building sample: {a['n']}/{MIN_SAMPLE} rounds before showing trend summaries.\n"
            "_No next-round prediction is possible from this data._"
        )
    rates = a["rates"]
    # Label is intentionally descriptive; never a bet/entry instruction.
    if rates[2.0] >= 50:
        label = "Higher-than-half of this sample reached 2x"
    elif rates[2.0] <= 25:
        label = "One-quarter or fewer of this sample reached 2x"
    else:
        label = "Mixed historical results around the 2x threshold"
    return (
        f"🛰️ *Aviator Intel — new round: {multiplier:.2f}x*\n"
        f"*Sample observation:* {label}.\n"
        f"Last {a['n']} rounds: 2x+ = *{rates[2.0]:.1f}%*, "
        f"3x+ = *{rates[3.0]:.1f}%*, 5x+ = *{rates[5.0]:.1f}%*.\n"
        "_This is a historical summary, not a prediction or recommendation to bet._"
    )

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    add_subscriber(update.effective_chat.id)
    await update.message.reply_text(
        "🛩️ *Aviator Intel is active.*\n"
        "You are subscribed to analysis alerts when new rounds arrive from the configured feed.\n\n"
        "/stats — recent multiplier statistics\n"
        "/signals — latest historical trend summary\n"
        "/help — setup and limitations",
        parse_mode="Markdown"
    )

async def stats_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(format_stats(), parse_mode="Markdown")

async def signals_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    rows = recent_rounds(1)
    if not rows:
        msg = "No round data received yet. The feed must send at least one result."
    else:
        msg = format_signal(float(rows[0]["multiplier"]))
    await update.message.reply_text(msg, parse_mode="Markdown")

async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Aviator Intel receives round results from a separately configured, authorized feed.\n\n"
        "Commands:\n/start — subscribe to alerts\n/stats — rolling sample statistics\n/signals — latest trend summary\n\n"
        "The bot does not access BetMGM accounts, bypass protections, place bets, or know future crash points. "
        "Do not send your BetMGM password, session cookie, or account details to anyone.",
    )

class RoundPayload(BaseModel):
    multiplier: float = Field(gt=0, le=100000)
    source: str = Field(default="authorized-feed", max_length=80)

api = FastAPI(title="Aviator Intel ingestion API")
telegram_app: Optional[Application] = None
event_loop: Optional[asyncio.AbstractEventLoop] = None

@api.get("/health")
def health():
    return {"status": "ok", "service": "Aviator Intel"}

@api.post("/round")
async def receive_round(payload: RoundPayload, x_ingest_key: str = Header(default="")):
    if x_ingest_key != INGEST_KEY:
        raise HTTPException(status_code=401, detail="Unauthorized")
    add_round(payload.multiplier, payload.source)
    message = format_signal(payload.multiplier)
    if telegram_app:
        for chat_id in subscribers():
            try:
                await telegram_app.bot.send_message(
                    chat_id=chat_id, text=message, parse_mode="Markdown"
                )
            except Exception:
                log.exception("Could not notify chat %s", chat_id)
    return {"accepted": True, "round": payload.multiplier}

def run_api():
    uvicorn.run(api, host="0.0.0.0", port=int(os.getenv("PORT", "8000")))

async def main():
    global telegram_app
    init_db()
    telegram_app = Application.builder().token(BOT_TOKEN).build()
    telegram_app.add_handler(CommandHandler("start", start))
    telegram_app.add_handler(CommandHandler("stats", stats_cmd))
    telegram_app.add_handler(CommandHandler("signals", signals_cmd))
    telegram_app.add_handler(CommandHandler("help", help_cmd))

    threading.Thread(target=run_api, daemon=True).start()
    log.info("Aviator Intel bot starting")
    await telegram_app.initialize()
    await telegram_app.start()
    await telegram_app.updater.start_polling()
    try:
        await asyncio.Event().wait()
    finally:
        await telegram_app.updater.stop()
        await telegram_app.stop()
        await telegram_app.shutdown()

if __name__ == "__main__":
    asyncio.run(main())
