# Aviator Intel — Telegram analysis bot

A starter Telegram bot that stores multiplier results, calculates rolling historical
frequencies, and sends descriptive alerts when a configured results source posts a
new round.

## What it does
- `/start` subscribes the Telegram chat to alerts.
- `/stats` reports the latest rolling sample's average and historical frequencies
  for 1.5x, 2x, 3x, 5x, and 10x.
- `/signals` repeats the latest descriptive trend summary.
- `POST /round` accepts a multiplier from an authorized data source and sends alerts.

## Important limitation
This project does **not** connect to BetMGM or extract live results by itself.
You must connect a legitimate, permitted results feed that you control or are
authorized to use. The screenshot alone cannot provide a live feed. Do not use
private endpoints, session cookies, account passwords, or bypass site protections.
The statistics are historical descriptions, not predictions of the next round.
The bot never places bets.

## Setup
1. Install Python 3.11 or newer.
2. Create a Telegram bot using Telegram's official `@BotFather`.
3. Copy the bot token into `.env` using `.env.example` as a template.
4. Install dependencies: `pip install -r requirements.txt`
5. Set environment variables from `.env` in your hosting environment.
6. Run: `python bot.py`
7. Open your bot in Telegram and send `/start`.

Keep `.env` private. Never paste your bot token into public chats or code repositories.
If a token is exposed, revoke it through `@BotFather` and generate a new one.

## Feed integration
Send a JSON POST request to your deployed service's `/round` endpoint:

```bash
curl -X POST "https://YOUR-SERVICE.example/round" \
  -H "Content-Type: application/json" \
  -H "X-Ingest-Key: YOUR_INGEST_KEY" \
  -d '{"multiplier": 1.62, "source": "authorized-feed"}'
```

A successful response looks like:

```json
{"accepted": true, "round": 1.62}
```

The source should submit each completed round once. Protect the endpoint with HTTPS
and a strong `INGEST_KEY`. The starter API does not deduplicate events, so the feed
adapter should avoid sending duplicate rounds.

## Deploying
Deploy the project to a Python-capable host that supports a persistent process,
environment variables, HTTPS ingress, and persistent disk for SQLite. Start command:
`python bot.py`.

For production, use a managed database and add feed-specific authentication,
deduplication, monitoring, and backups.
